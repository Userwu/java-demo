package com.zido.first;

import com.alibaba.fastjson.JSONObject;

/**
 * test.
 * Date: 2017/2/23 0023
 * Time: 14:25
 *
 * @author <a href="http://userwu.github.io">wuhongxu</a>.
 * @version 1.0.0
 */
public class JsonTest {
    public static void main(String[] args) {
        final JSONObject obj = new JSONObject();
        obj.put("first","ooxx");
        obj.put("second","xxoo");
        System.out.println();
    }
}
