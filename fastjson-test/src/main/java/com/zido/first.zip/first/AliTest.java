package com.zido.first;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alipay.api.internal.util.AlipaySignature;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * test.
 * Date: 2017/2/24 0024
 * Time: 9:33
 *
 * @author <a href="http://userwu.github.io">wuhongxu</a>.
 * @version 1.0.0
 */
public class AliTest {
    /**
     * 创建阿里订单信息
     *
     * @param orderInfo 订单详细信息,附加数据
     * @param orderId   订单id号码,可能重复
     * @param subject   订单支付提示信息
     * @param body      订单附加信息
     * @param price     订单价格
     * @return
     * @throws Exception
     */
    public final static String createAlipayInfo(String orderInfo, String orderId, String subject, String body, String price) throws Exception {
        //StringBuilder builder = new StringBuilder("service=\"mobile.securitypay.createOrder\"&payment_type=\"1\"&_input_charset=\"utf-8\"&it_b_pay=\"10m\"");

        final AliQueryBuilder ali = new AliQueryBuilder();
        ali.setApp_id(AlipayConfig.appId)
                .setMethod(AlipayConfig.Method.PAY)
                .setFormat("JSON")
                .setCharset("utf-8")
                .setSign_type("RSA2")
                .setTimestamp(DateUtil.formatDateTime(new Date()))
                .setVersion("1.0")
                .setNotify_url(AlipayConfig.NOTIFY_URL);
        /*
        * TODO 此参数尚未加上
        * builder.append("&order_attach=\"");
        * builder.append(orderInfo);//拼接商户个人订单信息
        * builder.append("\"");
        * */
        Map<String, String> bizContentMap = new HashMap<String, String>();
        bizContentMap.put(AliQueryBuilder.Content.body, body);
        bizContentMap.put(AliQueryBuilder.Content.subject, subject);
        bizContentMap.put(AliQueryBuilder.Content.out_trade_no, orderId);
        bizContentMap.put(AliQueryBuilder.Content.timeout_express, "90m");
        bizContentMap.put(AliQueryBuilder.Content.total_amount, price);
        bizContentMap.put(AliQueryBuilder.Content.seller_id, AlipayConfig.partner);
        bizContentMap.put(AliQueryBuilder.Content.product_code, "QUICK_MSECURITY_PAY");
        ali.setBiz_content(JSON.toJSON(bizContentMap).toString());
        //.setGoods_type("0") 商品类型
        //.setPassback_param("") 回传参数，可用于校验
        //签名
        String signStr = AlipaySignature.rsaSign(ali.getMap(), AlipayConfig.private_key, "utf-8");
//        RSA.sign(JSONObject.toJSON(ali).toString(), AlipayConfig.private_key, "utf-8");
        Map<String, String> queryMap = ali.encode();

        final Map<String, String> parMap = AlipayCore.paraFilter(queryMap);
        final Set<String> sets = parMap.keySet();
        for (String set : sets) {
            System.out.println(set);
        }
        String str = AlipayCore.createLinkString(parMap);
        str += "&sign="+ URLEncoder.encode(signStr,"UTF-8");

        System.out.println("------------------------------------------\n" +
                "------------" + str + "----------------\n" +
                "----------------------------------------\n");

        System.out.println(URLDecoder.decode("f63hirtW4G0NNF99AsQ%2BZ2ZPL3nRmgiz2ygwV6FPgy8TifDwyut9tpzS1nLmRYYWsKnK32bloH5%2BFGW%2Bw7k%2FlzcckDjcFSBVIm7%2BH1CVQVIgHVM48hwmWp4zt%2FjnVOBPT%2BUsFvp17rtS8d4GqiU8iK5xcZGlzI0xMq46uy4vZGRawBWakVTxQxBwsc906xX%2BuhtxwnZtimdfpYX5bYGizxki2CJYhlBcz54B%2Fm6Op%2B6b5%2FoZDHtnhuiLNhlxCamJ2fKM%2BxxFrN1E0%2BCTY2WUmMnJmTX2OG2zK32hTWiPGlunJPLpM94TRfijvaG4z%2FSenSDkTLPzNegZ0rshShrc%2Fw%3D%3D","UTF-8"));
        return str;


    }

    public static void main(String[] args) {
        try {
            AliTest.createAlipayInfo("i-n-f-o",
                    "o-r-d-e-r-i-d",
                    "s-u-b-j-e-c-t",
                    "b-o-d-y",
                    "20");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String alipay(String body, String subject, String out_trade_no, String total_amount) throws Exception {

        //公共参数
        Map<String, String> map = new HashMap<String, String>();
        map.put("app_id", AlipayConfig.appId);
        map.put("method", "alipay.trade.app.pay");
        map.put("format", "json");
        map.put("charset", "utf-8");
        map.put("sign_type", "RSA");
        map.put("timestamp", DateUtil.formatDateTime(new Date()));
        map.put("version", "1.0");
        map.put("notify_url", AlipayConfig.service);

        Map<String, String> m = new HashMap<>();

        m.put("body", body);
        m.put("subject", subject);
        m.put("out_trade_no", out_trade_no);
        m.put("timeout_express", "30m");
        m.put("total_amount", total_amount);
        m.put("seller_id", AlipayConfig.partner);
        m.put("product_code", "QUICK_MSECURITY_PAY");

        JSONObject bizcontentJson= (JSONObject) JSON.toJSON(m);

        map.put("biz_content", bizcontentJson.toString());
        //对未签名原始字符串进行签名
        String rsaSign = AlipaySignature.rsaSign(map, AlipayConfig.private_key, "utf-8");

        Map<String, String> map4 = new HashMap<String, String>();

        map4.put("app_id", AlipayConfig.appId);
        map4.put("method", "alipay.trade.app.pay");
        map4.put("format", "json");
        map4.put("charset", "utf-8");
        map4.put("sign_type", "RSA");
        map4.put("timestamp", URLEncoder.encode(DateUtil.formatDateTime(new Date()),"UTF-8"));
        map4.put("version", "1.0");
        map4.put("notify_url",  URLEncoder.encode(AlipayConfig.service,"UTF-8"));
        //最后对请求字符串的所有一级value（biz_content作为一个value）进行encode，编码格式按请求串中的charset为准，没传charset按UTF-8处理
        map4.put("biz_content", URLEncoder.encode(bizcontentJson.toString(), "UTF-8"));

        Map par = AlipayCore.paraFilter(map4); //除去数组中的空值和签名参数
        String json4 = AlipayCore.createLinkString(map4);   //拼接后的字符串

        json4=json4 + "&sign=" + URLEncoder.encode(rsaSign, "UTF-8");

        System.out.println(json4);

        return json4;

    }
}
